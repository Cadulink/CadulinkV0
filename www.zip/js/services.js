angular.module('starter.services', [])
