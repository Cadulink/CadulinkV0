angular.module('smallads.data', []);

var smallads = [
];
