angular.module('comments.data', []);

var comments = [
];
