angular.module('articles.service', ['articles.data', 'communities.data', 'people.data','comments.data'])

.factory('CommentService', function() {
    return {

    };
});
