angular.module('people.service', ['articles.data', 'communities.data', 'people.data','comments.data','smallads.data'])

.factory('SmallAdService', function() {
    return {
    };
});

